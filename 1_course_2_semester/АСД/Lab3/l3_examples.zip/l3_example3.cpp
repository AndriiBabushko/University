#include <stdio.h>
#include <windows.h>
#include <stdint.h>

// Отримання значення з елементу масиву
int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);

    uint32_t arr[] = {0, 1, 0, 5, 7, 2, 5, 0, 7, 7, 1, 0, 3, 4, 6, 0, 3};
    uint8_t len = sizeof(arr)/sizeof(arr[0]);

    uint8_t num = 6;
    uint32_t val = 255;

    if(num < len) {
        val = arr[num];
    }

    printf("Значення елементу %u - %u\n", num, val);

    return 0;
}
