#include <stdio.h>
#include <windows.h>
#include <stdint.h>

// Розрахунок складної суми елементів масиву
uint32_t sum(uint8_t i, uint32_t * m) {

    if(i == 0)
        return m[0];
    if(i == 1)
        return m[0] + m[1];

    return sum(i-2, m) + sum(i-1, m);
}


int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);

    uint32_t arr[] = {0, 1, 0, 5, 7, 2, 5, 0, 7, 7, 1, 0, 3, 4, 6, 0, 3};
    uint8_t len = sizeof(arr)/sizeof(arr[0]);

    uint32_t s = sum(len-1, &arr[0]);

    printf("Сума елементів масиву - %u\n", s);

    return 0;
}
