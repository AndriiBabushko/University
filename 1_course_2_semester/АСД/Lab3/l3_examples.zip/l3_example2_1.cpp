#include <stdio.h>
#include <windows.h>
#include <stdint.h>

// Знаходження кількість кожного значення у масиві
//1й варіант
int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);

    uint32_t arr[] = {0, 1, 0, 5, 7, 2, 5, 0, 7, 7, 1, 0, 3, 4, 6, 0, 3};
    uint8_t len = sizeof(arr)/sizeof(arr[0]);

    const uint8_t digit = 8;
    uint8_t count[digit]{};

    for(uint8_t j=0; j < digit; j++) {
        for(uint8_t i=0; i < len; i++) {
            if(arr[i] == j) count[j]++;
        }
        printf("Кількість '%u' - %u\n", j, count[j]);
    }

    return 0;
}
