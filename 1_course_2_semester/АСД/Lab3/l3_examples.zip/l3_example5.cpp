#include <stdio.h>
#include <windows.h>
#include <stdint.h>

// Знаходження кількості нулів в 2-мірному масиві
int main()
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);

    uint32_t arr[][4] = {{0, 1, 0, 5}, {7, 2, 5, 0}, {7, 7, 1, 0}, {3, 4, 6, 0}};
    uint8_t row = sizeof(arr)/sizeof(arr[0]);
    uint8_t col = sizeof(arr[0])/sizeof(arr[0][0]);
    uint8_t count = 0;

    for(uint8_t i=0; i < row; i++) {
        for(uint8_t j=0; j < col; j++) {
            if(arr[i][j] == 0) count++;
        }
    }
    printf("Кількість '0' - %u\n", count);

    return 0;
}
